# chimee 的事件机制

