export default {
  width: '100%',
  height: '100%',
  position: 'relative',
  display: 'block',
};
