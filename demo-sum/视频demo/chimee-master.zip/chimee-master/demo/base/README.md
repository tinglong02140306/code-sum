# Base demo of Chimee

You can use this base demo to know how Chimee work.