# Base demo of Chimee

> Chimee is a video-player aims to build wonderful experience on browser.

You can use this base demo to know how Chimee's plugin work.