import Play from '../src/play';

describe('init', function () {

});
